from super_processor.cli import main


def test_self_test_command(capsys) -> None:
    assert main(["self-test", "--limit", "5"]) == 0
    assert capsys.readouterr().out == "sum_of_squares(5) = 30\n"


def test_no_command_prints_help(capsys) -> None:
    assert main([]) == 0
    assert "Local-first AI-assisted video processing." in capsys.readouterr().out
