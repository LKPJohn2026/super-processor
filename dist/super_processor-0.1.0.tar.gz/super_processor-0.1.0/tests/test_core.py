from array import array

import pytest

from super_processor import mean, sum_of_squares


@pytest.mark.parametrize(
    ("limit", "expected"),
    [
        (0, 0),
        (1, 0),
        (5, 30),
        (10, 285),
    ],
)
def test_sum_of_squares(limit: int, expected: int) -> None:
    assert sum_of_squares(limit) == expected


def test_mean_accepts_contiguous_double_buffer() -> None:
    values = array("d", [1.0, 2.0, 6.0])
    assert mean(values) == pytest.approx(3.0)


def test_mean_rejects_empty_buffer() -> None:
    with pytest.raises(ValueError, match="must not be empty"):
        mean(array("d"))
