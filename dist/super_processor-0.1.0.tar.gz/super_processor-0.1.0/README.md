# Super Processor

Local-first AI-assisted video processing without generative frame synthesis.

Super Processor combines computer-vision measurements, constrained AI planning,
and deterministic FFmpeg pipelines. The model proposes a validated recipe; it
never writes arbitrary shell commands or renders the source video itself.

Read [the system design](docs/system-design.md) for the product decisions,
reasoning, and comparison with generative video tools and black-box enhancers.

## Repository template

This repository includes a conventional `src`-layout Cython package:

- PEP 517 builds through `pyproject.toml` and setuptools
- a compiled extension in `src/super_processor/_core.pyx`
- type information and package data for built distributions
- pytest and Ruff configuration
- source and wheel distribution support
- a Python-version CI matrix
- an installable `super-processor` command

The compiled functions are intentionally small toolchain checks. They provide a
known-good base for adding performance-sensitive frame statistics and media
analysis later.

## Requirements

- Python 3.10 or newer
- a C compiler supported by Python
- FFmpeg will be required by the video-processing application; it is not
  required for the included Cython toolchain tests

## Set up a development environment

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
```

Verify the compiled extension:

```bash
super-processor self-test
python -m pytest
python -m ruff check .
python -m build
```

## Project layout

```text
.
├── .github/workflows/ci.yml
├── docs/system-design.md
├── src/super_processor/
│   ├── __init__.py
│   ├── __main__.py
│   ├── _core.pyx
│   ├── _core.pyi
│   ├── cli.py
│   └── py.typed
├── tests/
├── MANIFEST.in
├── pyproject.toml
└── setup.py
```

## Build artifacts

Build an sdist and wheel:

```bash
python -m build
```

Generate Cython's annotated HTML while developing an extension:

```bash
cython --annotate src/super_processor/_core.pyx
```
