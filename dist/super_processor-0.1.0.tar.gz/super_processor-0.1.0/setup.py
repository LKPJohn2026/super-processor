from __future__ import annotations

from Cython.Build import cythonize
from setuptools import Extension, setup

extensions = [
    Extension(
        name="super_processor._core",
        sources=["src/super_processor/_core.pyx"],
    ),
]


setup(
    ext_modules=cythonize(
        extensions,
        compiler_directives={
            "binding": True,
            "language_level": "3",
        },
    ),
)
