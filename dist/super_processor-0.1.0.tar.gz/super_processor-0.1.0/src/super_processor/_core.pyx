# cython: language_level=3

"""Small compiled primitives used to verify the Cython toolchain."""


cpdef unsigned long long sum_of_squares(unsigned int limit):
    """Return the sum of ``value * value`` for ``0 <= value < limit``."""
    cdef unsigned int value
    cdef unsigned long long total = 0

    with nogil:
        for value in range(limit):
            total += <unsigned long long>value * value

    return total


cpdef double mean(const double[::1] values):
    """Return the arithmetic mean of a contiguous double-precision buffer."""
    cdef Py_ssize_t index
    cdef Py_ssize_t length = values.shape[0]
    cdef double total = 0.0

    if length == 0:
        raise ValueError("values must not be empty")

    with nogil:
        for index in range(length):
            total += values[index]

    return total / length
