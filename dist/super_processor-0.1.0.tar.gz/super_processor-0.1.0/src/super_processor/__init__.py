"""Super Processor's public Python API."""

from importlib.metadata import PackageNotFoundError, version

from ._core import mean, sum_of_squares

try:
    __version__ = version("super-processor")
except PackageNotFoundError:
    __version__ = "0+unknown"

__all__ = ["__version__", "mean", "sum_of_squares"]
