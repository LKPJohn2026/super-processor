from __future__ import annotations

import argparse
from collections.abc import Sequence

from . import __version__, sum_of_squares


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="super-processor",
        description="Local-first AI-assisted video processing.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command")
    self_test = subparsers.add_parser(
        "self-test",
        help="verify that the compiled Cython extension can run",
    )
    self_test.add_argument(
        "--limit",
        type=int,
        default=10,
        help="exclusive upper bound for the test calculation (default: 10)",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "self-test":
        if args.limit < 0:
            parser.error("--limit must be non-negative")
        result = sum_of_squares(args.limit)
        print(f"sum_of_squares({args.limit}) = {result}")
        return 0

    parser.print_help()
    return 0
