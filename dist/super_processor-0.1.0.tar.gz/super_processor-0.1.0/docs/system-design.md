# Super Processor — System Design

Super Processor is a local-first video enhancement system. It processes existing
footage with computer-vision measurements, constrained AI planning, and
deterministic FFmpeg pipelines. It does not generate or replace frames in v1.

The central design choice is to use AI as a control plane around proven media
tools, not as the media renderer itself.

## Market position

The current AI-video market is split into three broad groups:

| Market category | Strength | Common weakness | Super Processor's position |
|---|---|---|---|
| Generative video tools | Create short clips from text or images | Object morphing, temporal drift, anatomy and physics errors, text distortion, invented camera context | Does not synthesize frames; preserves source footage |
| Traditional editors and raw FFmpeg | Precise and deterministic | Require substantial editing and codec expertise | Uses diagnosis and safe recipes to reduce manual work |
| Black-box AI enhancers | Simple one-click restoration | Opaque changes, fixed model/vendor, possible texture invention, limited auditability | Exposes a validated recipe and requires a preview |

Generative products optimize for creating something new. Super Processor
optimizes for making an existing video more usable without changing what
happened in it. That boundary is the main product differentiator and the main
technical risk-control mechanism.

## Product and architecture decisions

### 1. Enhancement first, generation excluded

**Decision:** v1 is a processor, not a generator. It supports contrast
correction, white balance, denoising, stabilization, and vertical social export.
Text-to-video, image-to-video, inpainting, generative upscaling, and synthetic
frame creation are excluded.

**Reasoning:** Frame synthesis introduces failure classes that a processing tool
does not need to accept: disappearing objects, changing identities, impossible
motion, malformed anatomy, unstable text, and long-horizon temporal drift.
Preserving the source frames gives the system a much narrower and more
testable contract.

**Market comparison:** Generative systems compete on novelty and visual impact.
Super Processor competes on faithfulness, repeatability, and control.

### 2. Command-line interface for v1

**Decision:** v1 is a CLI. It creates preview files that can be opened with VLC
or `ffplay`; it does not include an Electron, Tauri, or native desktop shell.

**Reasoning:** A CLI exposes the real processing workflow—inputs, manifests,
recipes, logs, and outputs—without coupling the media engine to an early UI.
It also makes the processor scriptable and suitable for batch workflows.

**Market comparison:** Most consumer AI-video products are web applications
with hidden pipelines. A CLI favors technical users who want automation and
inspectable artifacts.

### 3. Media processing stays local

**Decision:** `ffprobe`, feature extraction, preview rendering, and final
encoding run on the user's machine. Media is not uploaded by default.

**Reasoning:** Target inputs can be 4–10 GB and 90–120 minutes long. Local
processing avoids upload latency, cloud storage cost, and unnecessary exposure
of private footage. It also makes the result reproducible against a known
FFmpeg build.

**Market comparison:** Hosted AI-video services generally require uploads and
meter processing through subscriptions or credits. Super Processor trades cloud
convenience for privacy and user-controlled compute.

### 4. Local models and BYOK use one provider contract

**Decision:** The planner and optional vision-language model can use local
OpenAI-compatible endpoints such as Ollama or LM Studio, or user-provided API
keys for supported cloud providers.

**Reasoning:** Users should be able to choose privacy, cost, latency, and model
quality without changing the processing architecture. Provider adapters produce
the same structured outputs and are replaceable.

**Market comparison:** Most AI-video tools bind the product to one hosted model.
Super Processor makes model choice an infrastructure concern rather than a
product lock-in.

### 5. The LLM produces recipes, never shell commands

**Decision:** The planner may emit only versioned Recipe JSON. It cannot emit
raw shell commands, arbitrary FFmpeg arguments, filter names, or paths.

The validator checks:

- JSON schema and recipe version
- operation allowlist
- parameter ranges and units
- legal operation ordering
- compatibility with `ffprobe` facts
- expected disk and runtime requirements
- social-export bitrate feasibility

Validated operations are translated into FFmpeg arguments by engineering-owned
templates.

**Reasoning:** Free-form command generation can invent filters, misuse flags,
ignore colorspace metadata, or produce unsafe paths. A narrow recipe language
keeps model flexibility while making execution deterministic.

**Market comparison:** Generative tools can hallucinate in pixel space, while
general-purpose coding assistants can hallucinate in command space. Super
Processor removes both from its critical rendering path.

### 6. Automatic diagnosis is primary; natural language is refinement

**Decision:** The normal flow starts with measured diagnosis and suggested
operations. Natural-language requests such as “use less denoise” or “make the
white balance slightly warmer” patch an existing recipe.

**Reasoning:** Users often recognize a bad result without knowing the relevant
filter. Computer-vision measurements provide grounded defaults. Natural
language is useful for preference changes, but it should not invent a pipeline
from no evidence.

**Market comparison:** Generative tools are prompt-first and traditional
editors are control-first. Super Processor is measurement-first and
human-approved.

### 7. Classical computer vision sets v1 parameters

**Decision:** v1 uses signal-processing and computer-vision estimators for
histograms, luminance percentiles, color cast, noise, sharpness, global motion,
scene cuts, faces, saliency, black bars, and text regions. These estimators set
priors for FFmpeg filters. Learned on-device enhancement models are deferred.

**Reasoning:** Classical measurements are fast, inspectable, and suitable for
sampling long videos. Neural restoration can redraw texture or introduce
frame-to-frame inconsistency, weakening the product's faithfulness guarantee.

**Market comparison:** Black-box enhancers often make a neural network the
renderer. Super Processor initially uses AI and CV to choose parameters while
FFmpeg remains the renderer.

### 8. A preview and explicit approval are mandatory

**Decision:** A final encode requires a successful preview for the current
recipe and explicit user approval. Changing the recipe invalidates the previous
approval.

**Reasoning:** Denoising, stabilization, color correction, and reframing are
partly subjective. A short preview catches plastic detail, bad crops, flicker,
or an unwanted color shift before a multi-hour software encode.

**Market comparison:** One-click enhancers often reveal the full result only
after processing. Super Processor makes review a state transition in the job,
not an optional suggestion.

### 9. v1 operations are intentionally narrow

| Operation | Measured inputs | Rendering strategy | Primary guardrail |
|---|---|---|---|
| Contrast | Luminance histogram, percentiles, clipping | `eq` or bounded curves | Preserve highlight and shadow detail |
| White balance | Neutral-pixel statistics, channel cast, estimated color temperature | Bounded color/temperature adjustment | Avoid over-correcting mixed lighting |
| Denoise | Flat-region noise, sharpness, blockiness, text regions | Allowlisted FFmpeg denoiser with capped strength | Preserve edges, faces, and text |
| Stabilize | Global motion, scene cuts, estimated crop loss | Analyze/apply stabilization pass | Cap crop and keep subjects visible |
| Vertical social export | Faces, saliency, black bars, duration, size cap | Tracked crop, scale, and HEVC encode | Keep subjects in frame and reject infeasible caps |

**Reasoning:** These operations address common real-footage problems and have
mature deterministic implementations. A small allowlist is easier to evaluate
well than a large collection of weakly guarded filters.

### 10. Full-timeline vertical export is supported with a feasibility gate

**Decision:** Social export processes the entire timeline, not only highlights.
Before rendering, the system calculates the bitrate available under the
requested size cap. It refuses an impossible request or warns and requires
acknowledgment when expected quality is marginal.

**Reasoning:** A two-hour video under a small file-size cap can be mathematically
incapable of acceptable quality. Silently satisfying the byte limit would
produce severe blockiness and temporal artifacts.

**Market comparison:** Generative products mostly target short vertical clips.
Super Processor supports long-form vertical delivery but treats bitrate as an
explicit engineering constraint.

### 11. Software HEVC is the single v1 encode path

**Decision:** v1 uses software `libx265`. Hardware encoders such as NVENC, QSV,
AMF, and VideoToolbox are deferred.

**Reasoning:** One encoder reduces platform variance while recipe quality and
size-cap behavior are established. The CLI must provide progress and an honest
ETA because long files may take hours.

**Market comparison:** Cloud services hide rendering hardware behind credits.
Super Processor exposes the local cost and keeps the output path predictable.

### 12. Quality is evaluated with references offline and safeguards at runtime

**Decision:** Offline evaluation uses clean reference clips, controlled
degradations, and restored outputs. VMAF is recorded alongside operation-specific
metrics:

- highlight and shadow clipping for contrast
- color error for white balance
- residual noise and edge retention for denoise
- residual camera motion and crop loss for stabilization
- subject retention, aspect ratio, and output size for social export

Runtime footage normally has no clean reference. Runtime checks therefore focus
on executable recipe validity, excessive detail loss, subject cutoff,
introduced flicker, and text readability. The user remains the final quality
judge through preview approval.

**Reasoning:** VMAF alone does not identify whether a particular correction is
right, and it cannot be computed meaningfully without a reference. Combining
reference metrics, task metrics, and human approval avoids pretending that one
score captures video quality.

**Market comparison:** Generative benchmarks reward prompt adherence and
short-clip appearance. Super Processor measures faithful repair and regression
risk.

### 13. Long videos are sampled for diagnosis and streamed for output

**Decision:** Diagnosis uses stratified samples across the timeline plus
scene-change and severity candidates. Full media is never loaded into memory.
Expensive analysis artifacts, such as stabilization transforms, are cached in
the job directory.

**Reasoning:** Feature-length inputs make exhaustive AI inspection too slow and
expensive. Sampling is sufficient for proposing a plan, while streaming keeps
memory bounded during final processing.

**Market comparison:** Many AI-video systems are designed around short clips
that fit a model context. Super Processor's data flow is designed for long-form
media from the beginning.

### 14. Privacy boundaries are explicit

**Decision:** Probe facts, recipes, logs, and metrics remain local by default.
If a cloud vision model is enabled, the CLI must disclose that sampled frames
will leave the machine before sending them. API keys are read from environment
variables or an OS keyring and are redacted from logs.

**Reasoning:** “Local processing” would be misleading if diagnostic frames were
silently sent to a model provider.

**Market comparison:** Hosted products make cloud processing implicit. Super
Processor makes every network boundary a user choice.

## Resulting system

```text
input video
    │
    ▼
ffprobe facts ──► sampled CV features ──► optional VLM advice
    │                       │                       │
    └───────────────────────┴───────────────► diagnosis
                                                │
                                                ▼
                                      planner → Recipe JSON
                                                │
                                                ▼
                         schema + policy + feasibility validator
                                                │
                                                ▼
                                  FFmpeg preview segment
                                                │
                                      VLC / ffplay review
                                                │
                                      explicit user approval
                                                │
                                                ▼
                              full-timeline `libx265` encode
                                                │
                                                ▼
                              output probe and constraint report
```

The intended CLI surface is:

```text
super-processor doctor
super-processor models
super-processor diagnose INPUT
super-processor plan --job JOB [--request "..."]
super-processor preview --job JOB [--open vlc|ffplay]
super-processor apply --job JOB --approve
super-processor show JOB
```

Each job persists its media facts, feature summary, diagnosis, recipe, preview,
approval state, logs, cached analysis, and output report. This makes a result
reproducible and makes failures debuggable without asking an LLM to remember
what it did.

## v1 boundaries

- No generated or replaced video frames
- No neural restoration renderer
- No desktop GUI
- No hardware encoding
- No cloud media-processing service
- No full nonlinear editing timeline
- No arbitrary user-provided FFmpeg fragments in AI-generated recipes

These boundaries are not omissions to hide; they are the decisions that make
the v1 trust model coherent.
